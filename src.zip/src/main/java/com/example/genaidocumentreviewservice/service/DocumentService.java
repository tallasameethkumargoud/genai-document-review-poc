import { Component } from '@angular/core';
import { AuthService } from '../services/auth.service';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent {
    username: string = '';
    password: string = '';

    constructor(private authService: AuthService) { }

    onSubmit() {
    this.authService.login(this.username, this.password)
        .subscribe(
        (response) => {
            // Handle successful login response
            console.log('Login successful');
            // Store the authentication token in local storage or session storage
            localStorage.setItem('token', response.token);
            // Redirect the user to the desired page after login
        },
        (error) => {
            // Handle login error
            console.error('Login failed', error);
        }
        );
    }
}