package com.example.genaidocumentreviewservice.service;

   import java.util.regex.Pattern;

   public class PIIRedactor {

       public String redactSSN(String text) {
           return text.replaceAll("\\d{3}-\\d{2}-\\d{4}", "XXX-XX-XXXX");
       }

       public String redactAccountNumber(String text) {
           return text.replaceAll("\\d{10}", "XXXXXXXXXX");
       }

       public String redactIncome(String text) {
           return text.replaceAll("\\$\\d+(\\.\\d{1,2})