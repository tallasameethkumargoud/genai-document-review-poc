package com.example.genaidocumentreviewservice.controller;

import com.example.genaidocumentreviewservice.model.PayStub;
import com.example.genaidocumentreviewservice.service.PIIRedactor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/genai")
public class GenAIController {

    private final PIIRedactor piiRedactor;

    public GenAIController(PIIRedactor piiRedactor) {
        this.piiRedactor = piiRedactor;
    }

    @PostMapping("/extract")
    public PayStub extractPayStubData(@RequestBody String payStubText, @RequestParam Long applicationId, @RequestParam Long documentId) {
        String redactedText = piiRedactor.redactPII(payStubText);

        // Mock LLM API call
        PayStub extractedData = mockExtractPayStubData(redactedText);

        // Associate PayStub with Application
        applicationService.associatePayStub(applicationId, extractedData);

        // Retrieve pay stub text from Document Service (mocked)
        String payStubTextFromS3 = documentService.getPayStubText(documentId);

        return extractedData;
   } 

    private PayStub mockExtractPayStubData(String text) {
        PayStub payStub = new PayStub();
        payStub.setEmployerName("Acme Inc");
        payStub.setIncome(new BigDecimal("5000"));
        payStub.setPayPeriodStart(LocalDate.of(2023, 1, 1));
        payStub.setPayPeriodEnd(LocalDate.of(2023, 1, 31));
        return payStub;
    }
    private final ApplicationService applicationService;
    private final DocumentService documentService;

    public GenAIController(PIIRedactor piiRedactor, ApplicationService applicationService, DocumentService documentService) {
        this.piiRedactor = piiRedactor;
        this.applicationService = applicationService;
        this.documentService = documentService;
    }
}