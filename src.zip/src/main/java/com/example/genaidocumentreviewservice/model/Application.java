package com.example.genaidocumentreviewservice.model;

   import jakarta.persistence.Entity;
   import jakarta.persistence.GeneratedValue;
   import jakarta.persistence.GenerationType;
   import jakarta.persistence.Id;

   import java.math.BigDecimal;

   @Entity
   public class Application {
       @Id
       @GeneratedValue(strategy = GenerationType.IDENTITY)
       private Long id;

       private String firstName;
       private String lastName;
       private BigDecimal selfReportedIncome;

       // Add getters and setters
   }