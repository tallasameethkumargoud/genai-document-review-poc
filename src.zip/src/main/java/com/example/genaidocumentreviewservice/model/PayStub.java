package com.example.genaidocumentreviewservice.model;

   import jakarta.persistence.Entity;
   import jakarta.persistence.GeneratedValue;
   import jakarta.persistence.GenerationType;
   import jakarta.persistence.Id;

   import java.math.BigDecimal;
   import java.time.LocalDate;

   @Entity
   public class PayStub {
       @Id
       @GeneratedValue(strategy = GenerationType.IDENTITY)
       private Long id;

       private Long applicationId;
       private String employerName;
       private BigDecimal income;
       private LocalDate payPeriodStart;
       private LocalDate payPeriodEnd;

       // Add getters and setters
   }